package com.example.padforge;

import android.system.ErrnoException;
import android.system.Os;
import android.system.OsConstants;
import android.system.StructPollfd;

import java.io.FileDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * Roda como usuário "shell" (iniciado pelo Shizuku via app_process).
 * Testa se dá para pegar o controle real com exclusividade (EVIOCGRAB).
 * Fase 1: sem bloqueio. Fase 2: bloqueado. Fase 3: solto.
 * É só um teste: o bloqueio é solto sozinho ao fechar o arquivo.
 */
public class GrabTest {
    // _IOW('E', 0x90, int)
    private static final int EVIOCGRAB = 0x40044590;
    private static final long PHASE_MS = 4000;

    public static void main(String[] args) {
        try {
            if (args.length < 1) {
                say("ERRO: faltou o caminho do dispositivo.");
                return;
            }
            String path = args[0];
            int sz = System.getProperty("os.arch", "").contains("64") ? 24 : 16;
            say("Dispositivo: " + path + " (evento de " + sz + " bytes)");

            say("FASE 1: sem bloqueio");
            int[] r1 = phase(path, sz, false);
            if (r1 == null) return;

            say("FASE 2: bloqueado");
            int[] r2 = phase(path, sz, true);
            if (r2 == null) return;

            say("FASE 3: solto");
            int[] r3 = phase(path, sz, false);
            if (r3 == null) return;

            say("Eventos de eixo lidos pelo shell: fase1=" + r1[1]
                + " fase2(bloqueado)=" + r2[1] + " fase3=" + r3[1]);
        } catch (Throwable t) {
            say("FALHA no teste: " + t);
        } finally {
            System.exit(0);
        }
    }

    private static void say(String s) {
        System.out.println(s);
        System.out.flush();
    }

    /** Retorna {total de eventos, eventos de eixo} ou null se falhou. */
    private static int[] phase(String path, int sz, boolean grab) throws Exception {
        FileDescriptor fd;
        try {
            fd = Os.open(path, OsConstants.O_RDONLY, 0);
        } catch (ErrnoException e) {
            say("GRAB_FALHOU: não consegui abrir " + path + ": " + e.getMessage());
            return null;
        }

        if (grab) {
            String err = tryGrab(fd);
            if (err != null) {
                say("GRAB_FALHOU: " + err);
                try { Os.close(fd); } catch (ErrnoException ignored) { }
                return null;
            }
            say("T_GRAB_ON=" + System.currentTimeMillis());
        }

        Reader r = new Reader(fd, sz);
        r.start();
        Thread.sleep(PHASE_MS);
        r.stop = true;
        r.join(1000);

        // Fechar o arquivo solta o bloqueio.
        try { Os.close(fd); } catch (ErrnoException ignored) { }
        if (grab) say("T_GRAB_OFF=" + System.currentTimeMillis());
        return new int[] {r.total, r.abs};
    }

    private static String tryGrab(FileDescriptor fd) {
        try {
            Object os = Class.forName("libcore.io.Libcore").getField("os").get(null);
            Class<?> osCls = Class.forName("libcore.io.Os");
            try {
                Method m = osCls.getMethod("ioctlInt", FileDescriptor.class, int.class);
                m.invoke(os, fd, EVIOCGRAB);
                return null;
            } catch (NoSuchMethodException e1) {
                Class<?> ref = Class.forName("android.system.Int32Ref");
                Object arg = ref.getConstructor(int.class).newInstance(1);
                Method m = osCls.getMethod("ioctlInt", FileDescriptor.class, int.class, ref);
                m.invoke(os, fd, EVIOCGRAB, arg);
                return null;
            }
        } catch (InvocationTargetException e) {
            return "o sistema recusou o bloqueio: " + e.getCause();
        } catch (Throwable t) {
            return "chamada de bloqueio indisponível neste Android: " + t;
        }
    }

    private static class Reader extends Thread {
        final FileDescriptor fd;
        final int sz;
        volatile boolean stop = false;
        volatile int total = 0;
        volatile int abs = 0;

        Reader(FileDescriptor fd, int sz) {
            this.fd = fd;
            this.sz = sz;
            setDaemon(true);
        }

        @Override
        public void run() {
            byte[] buf = new byte[sz * 64];
            StructPollfd[] p = new StructPollfd[] { new StructPollfd() };
            p[0].fd = fd;
            p[0].events = (short) OsConstants.POLLIN;
            while (!stop) {
                try {
                    p[0].revents = 0;
                    int ready = Os.poll(p, 100);
                    if (ready > 0 && (p[0].revents & OsConstants.POLLIN) != 0) {
                        int n = Os.read(fd, buf, 0, buf.length);
                        for (int off = 0; off + sz <= n; off += sz) {
                            total++;
                            int type = (buf[off + sz - 8] & 0xFF) | ((buf[off + sz - 7] & 0xFF) << 8);
                            if (type == 3) abs++; // EV_ABS
                        }
                    }
                } catch (Exception e) {
                    break;
                }
            }
        }
    }
}
